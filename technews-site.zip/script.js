const noticias = [
  {
    titulo: "Inteligência Artificial Revoluciona o Mercado",
    resumo: "Tecnologias de IA estão redefinindo setores no Brasil e no mundo.",
    data: "24/04/2025"
  },
  {
    titulo: "5G e o Futuro da Conectividade",
    resumo: "Entenda como o 5G está moldando o futuro da internet móvel.",
    data: "23/04/2025"
  }
];
const newsList = document.getElementById('newsList');
noticias.forEach(noticia => {
  const card = document.createElement('div');
  card.classList.add('noticia');
  card.innerHTML = `
    <h2>${noticia.titulo}</h2>
    <p>${noticia.resumo}</p>
    <small>${noticia.data}</small>
  `;
  newsList.appendChild(card);
});
